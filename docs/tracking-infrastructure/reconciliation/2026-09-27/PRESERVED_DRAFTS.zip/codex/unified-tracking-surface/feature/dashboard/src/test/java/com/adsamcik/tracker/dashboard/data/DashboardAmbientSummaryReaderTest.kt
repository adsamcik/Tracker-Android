package com.adsamcik.tracker.dashboard.data

import com.adsamcik.tracker.shared.base.concurrency.TestDispatchersProvider
import com.adsamcik.tracker.shared.preferences.tracking.TrackingParamsState
import com.adsamcik.tracker.stats.api.repository.AmbientCellFact
import com.adsamcik.tracker.stats.api.repository.AmbientCellOrigin
import com.adsamcik.tracker.stats.api.repository.AmbientCellReadResult
import com.adsamcik.tracker.stats.api.repository.AmbientCellRepository
import com.adsamcik.tracker.stats.api.repository.AmbientStepsHistoryDay
import com.adsamcik.tracker.stats.api.repository.AmbientStepsHistoryRecentRead
import com.adsamcik.tracker.stats.api.repository.AmbientStepsHistoryRepository
import com.adsamcik.tracker.stats.api.repository.AmbientStepsHistoryValue
import com.adsamcik.tracker.stats.api.repository.AmbientStepsStructuralDay
import com.adsamcik.tracker.stats.api.repository.AmbientWifiReadResult
import com.adsamcik.tracker.stats.api.repository.AmbientWifiRepository
import io.kotest.matchers.shouldBe
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.every
import io.mockk.mockk
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Test

@OptIn(ExperimentalCoroutinesApi::class)
class DashboardAmbientSummaryReaderTest {
	private val steps = mockk<AmbientStepsHistoryRepository>()
	private val wifi = mockk<AmbientWifiRepository>()
	private val cell = mockk<AmbientCellRepository>()

	@Test
	fun `default off and missing policy projection never read any source`() = runTest {
		val reader = reader()
		reader.read(TrackingParamsState(), 100_000L) shouldBe null
		reader.read(TrackingParamsState(ambientStepsEnabled = true), 100_000L) shouldBe null
		coVerify(exactly = 0) { steps.readRecent(any()) }
		coVerify(exactly = 0) { wifi.read(any()) }
		coVerify(exactly = 0) { cell.read(any()) }
	}

	@Test
	fun `one failed source cannot remove independent Cell evidence`() = runTest {
		coEvery { wifi.read(any()) } throws IllegalStateException("read failed")
		val fact = mockk<AmbientCellFact>()
		every { fact.observedTimeMs } returns 90_000L
		every { fact.observationCount } returns 4
		coEvery { cell.read(any()) } returns AmbientCellReadResult.Snapshot(
			facts = listOf(fact), gaps = emptyList(),
			availability = com.adsamcik.tracker.stats.api.repository.AmbientCellAvailability.AVAILABLE,
		)

		reader().read(
			TrackingParamsState(
				sourcePolicyRevision = 1L,
				ambientWifiEnabled = true,
				ambientCellEnabled = true,
			),
			100_000L,
		) shouldBe DashboardAmbientSummary(
			steps = null,
			wifi = DashboardAmbientValue.Unavailable,
			cell = DashboardAmbientValue.Count(4L),
		)
		coVerify(exactly = 0) { steps.readRecent(any()) }
		coVerify(exactly = 1) {
			cell.read(match { it.origins == setOf(AmbientCellOrigin.LOCAL_DEVICE) })
		}
	}

	@Test
	fun `Steps uses between-session partial count rather than whole-day total`() = runTest {
		val day = mockk<AmbientStepsHistoryDay>()
		every { day.day } returns AmbientStepsStructuralDay(1L, "UTC")
		every { day.structuralDayEndTimeMs } returns 100_000L
		every { day.betweenSession } returns AmbientStepsHistoryValue.Partial(
			count = 11L,
			causes = setOf(mockk()),
		)
		coEvery { steps.readRecent(any()) } returns AmbientStepsHistoryRecentRead.Page(
			sourceEvidenceRevision = 1L,
			days = listOf(day),
			next = null,
		)
		reader().read(
			TrackingParamsState(sourcePolicyRevision = 1L, ambientStepsEnabled = true),
			100_000L,
		) shouldBe DashboardAmbientSummary(
			steps = DashboardAmbientValue.Count(11L, partial = true),
			wifi = null,
			cell = null,
		)
		coVerify(exactly = 0) { wifi.read(any()) }
		coVerify(exactly = 0) { cell.read(any()) }
	}

	private fun kotlinx.coroutines.test.TestScope.reader() = DashboardAmbientSummaryReader(
		steps = steps,
		wifi = wifi,
		cell = cell,
		dispatchers = TestDispatchersProvider(StandardTestDispatcher(testScheduler)),
	)
}
