package com.adsamcik.tracker.dashboard.data

import com.adsamcik.tracker.shared.base.concurrency.DispatchersProvider
import com.adsamcik.tracker.shared.preferences.tracking.TrackingParamsState
import com.adsamcik.tracker.stats.api.repository.AmbientCellOrigin
import com.adsamcik.tracker.stats.api.repository.AmbientCellReadRequest
import com.adsamcik.tracker.stats.api.repository.AmbientCellReadResult
import com.adsamcik.tracker.stats.api.repository.AmbientCellRepository
import com.adsamcik.tracker.stats.api.repository.AmbientStepsHistoryRecentRead
import com.adsamcik.tracker.stats.api.repository.AmbientStepsHistoryRecentRequest
import com.adsamcik.tracker.stats.api.repository.AmbientStepsHistoryRepository
import com.adsamcik.tracker.stats.api.repository.AmbientStepsHistoryValue
import com.adsamcik.tracker.stats.api.repository.AmbientWifiOrigin
import com.adsamcik.tracker.stats.api.repository.AmbientWifiReadRequest
import com.adsamcik.tracker.stats.api.repository.AmbientWifiReadResult
import com.adsamcik.tracker.stats.api.repository.AmbientWifiRepository
import javax.inject.Inject
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withContext

/** Sessionless history is a separate product from the coordinated session page. */
data class DashboardAmbientSummary(
	val steps: DashboardAmbientValue?,
	val wifi: DashboardAmbientValue?,
	val cell: DashboardAmbientValue?,
) {
	val hasConsentedSource: Boolean get() = steps != null || wifi != null || cell != null
}

sealed interface DashboardAmbientValue {
	data object Loading : DashboardAmbientValue
	data object NoRecentEvidence : DashboardAmbientValue
	data class Count(val count: Long, val partial: Boolean = false) : DashboardAmbientValue {
		init { require(count >= 0L) }
	}
	data object Unavailable : DashboardAmbientValue
}

internal fun TrackingParamsState.loadingAmbientSummary(): DashboardAmbientSummary? {
	if (sourcePolicyRevision == null) return null
	return DashboardAmbientSummary(
		steps = DashboardAmbientValue.Loading.takeIf { ambientStepsEnabled },
		wifi = DashboardAmbientValue.Loading.takeIf { ambientWifiEnabled },
		cell = DashboardAmbientValue.Loading.takeIf { ambientCellEnabled },
	).takeIf(DashboardAmbientSummary::hasConsentedSource)
}

/** Reads each consented source independently; failure of one cannot erase the others. */
internal class DashboardAmbientSummaryReader @Inject constructor(
	private val steps: AmbientStepsHistoryRepository,
	private val wifi: AmbientWifiRepository,
	private val cell: AmbientCellRepository,
	private val dispatchers: DispatchersProvider,
) {
	suspend fun read(policy: TrackingParamsState, nowMs: Long): DashboardAmbientSummary? =
		withContext(dispatchers.io) {
			if (policy.sourcePolicyRevision == null) return@withContext null
			val end = nowMs.coerceAtLeast(1L)
			val start = (end - RECENT_WINDOW_MS).coerceAtLeast(0L)
			DashboardAmbientSummary(
				steps = if (policy.ambientStepsEnabled) safelyRead { readSteps(start) } else null,
				wifi = if (policy.ambientWifiEnabled) safelyRead { readWifi(start, end) } else null,
				cell = if (policy.ambientCellEnabled) safelyRead { readCell(start, end) } else null,
			).takeIf(DashboardAmbientSummary::hasConsentedSource)
		}

	private suspend fun safelyRead(read: suspend () -> DashboardAmbientValue): DashboardAmbientValue =
		try {
			read()
		} catch (cancelled: CancellationException) {
			throw cancelled
		} catch (_: Exception) {
			DashboardAmbientValue.Unavailable
		}

	private suspend fun readSteps(start: Long): DashboardAmbientValue =
		when (val result = steps.readRecent(AmbientStepsHistoryRecentRequest(limit = 1))) {
			is AmbientStepsHistoryRecentRead.Page -> {
				val day = result.days.firstOrNull()
				if (day == null || day.structuralDayEndTimeMs < start) {
					DashboardAmbientValue.NoRecentEvidence
				} else when (val value = day.betweenSession) {
					is AmbientStepsHistoryValue.Exact -> DashboardAmbientValue.Count(value.count)
					is AmbientStepsHistoryValue.Partial ->
						DashboardAmbientValue.Count(value.count, partial = true)
					is AmbientStepsHistoryValue.Unavailable -> DashboardAmbientValue.Unavailable
				}
			}
			else -> DashboardAmbientValue.Unavailable
		}

	private suspend fun readWifi(start: Long, end: Long): DashboardAmbientValue =
		when (val result = wifi.read(
			AmbientWifiReadRequest(start, end, setOf(AmbientWifiOrigin.LOCAL_DEVICE), RADIO_FACT_LIMIT),
		)) {
			is AmbientWifiReadResult.Snapshot -> result.facts.maxByOrNull { it.observedTimeMs }
				?.let { DashboardAmbientValue.Count(it.observationCount.toLong(), result.gaps.isNotEmpty()) }
				?: DashboardAmbientValue.NoRecentEvidence
			else -> DashboardAmbientValue.Unavailable
		}

	private suspend fun readCell(start: Long, end: Long): DashboardAmbientValue =
		when (val result = cell.read(
			AmbientCellReadRequest(start, end, setOf(AmbientCellOrigin.LOCAL_DEVICE), RADIO_FACT_LIMIT),
		)) {
			is AmbientCellReadResult.Snapshot -> result.facts.maxByOrNull { it.observedTimeMs }
				?.let { DashboardAmbientValue.Count(it.observationCount.toLong(), result.gaps.isNotEmpty()) }
				?: DashboardAmbientValue.NoRecentEvidence
			else -> DashboardAmbientValue.Unavailable
		}

	private companion object {
		const val RECENT_WINDOW_MS = 24L * 60L * 60L * 1_000L
		const val RADIO_FACT_LIMIT = 512
	}
}
