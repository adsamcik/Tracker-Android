package com.adsamcik.tracker.dashboard.ui.compose.cards

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.adsamcik.tracker.dashboard.R
import com.adsamcik.tracker.dashboard.data.DashboardAmbientSummary
import com.adsamcik.tracker.dashboard.data.DashboardAmbientValue
import com.adsamcik.tracker.shared.utils.style.compose.GlassCard

/** Separately consented, sessionless observations; never presented as a trip or route. */
@Composable
internal fun AmbientSummaryCard(summary: DashboardAmbientSummary, modifier: Modifier = Modifier) {
	if (!summary.hasConsentedSource) return
	GlassCard(modifier = modifier.fillMaxWidth().testTag("ambient_summary")) {
		Column(
			modifier = Modifier.padding(16.dp),
			verticalArrangement = Arrangement.spacedBy(8.dp),
		) {
			Text(
				text = stringResource(R.string.dashboard_ambient_title),
				style = MaterialTheme.typography.titleMedium,
			)
			Text(
				text = stringResource(R.string.dashboard_ambient_explanation),
				style = MaterialTheme.typography.bodySmall,
				color = MaterialTheme.colorScheme.onSurfaceVariant,
			)
			summary.steps?.let { AmbientRow(R.string.dashboard_ambient_steps, it, true) }
			summary.wifi?.let { AmbientRow(R.string.dashboard_ambient_wifi, it, false) }
			summary.cell?.let { AmbientRow(R.string.dashboard_ambient_cell, it, false) }
		}
	}
}

@Composable
private fun AmbientRow(labelRes: Int, value: DashboardAmbientValue, steps: Boolean) {
	Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
		Text(text = stringResource(labelRes), style = MaterialTheme.typography.bodyMedium)
		Text(
			text = when (value) {
				DashboardAmbientValue.Loading -> stringResource(R.string.dashboard_ambient_loading)
				DashboardAmbientValue.NoRecentEvidence -> stringResource(R.string.dashboard_ambient_none)
				DashboardAmbientValue.Unavailable -> stringResource(R.string.dashboard_ambient_unavailable)
				is DashboardAmbientValue.Count -> when {
					steps && value.partial -> stringResource(R.string.dashboard_ambient_steps_partial, value.count)
					steps -> stringResource(R.string.dashboard_ambient_steps_count, value.count)
					value.partial -> stringResource(R.string.dashboard_ambient_radio_partial, value.count)
					else -> stringResource(R.string.dashboard_ambient_radio_count, value.count)
				}
			},
			style = MaterialTheme.typography.bodyMedium,
		)
	}
}
