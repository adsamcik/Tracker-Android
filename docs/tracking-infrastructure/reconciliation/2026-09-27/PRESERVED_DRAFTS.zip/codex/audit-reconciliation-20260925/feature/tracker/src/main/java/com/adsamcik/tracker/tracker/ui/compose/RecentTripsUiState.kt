package com.adsamcik.tracker.tracker.ui.compose

import com.adsamcik.tracker.shared.model.Trip
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.scan

internal data class RecentTripsUiState(
	val trips: List<Trip> = emptyList(),
	val isLoading: Boolean = true,
	val readFailed: Boolean = false,
)

private sealed interface RecentTripsReadEvent {
	data object Loading : RecentTripsReadEvent
	data class Loaded(val trips: List<Trip>) : RecentTripsReadEvent
	data object Failed : RecentTripsReadEvent
}

/** A failed read preserves known rows and is never indistinguishable from a successful empty read. */
@OptIn(ExperimentalCoroutinesApi::class)
internal fun observeRecentTripsUiState(
	reload: Flow<Long>,
	initialState: () -> RecentTripsUiState = { RecentTripsUiState() },
	observe: () -> Flow<List<Trip>>,
): Flow<RecentTripsUiState> = flow {
	emitAll(
		reload.flatMapLatest {
			flow<RecentTripsReadEvent> {
				emit(RecentTripsReadEvent.Loading)
				emitAll(observe().map { RecentTripsReadEvent.Loaded(it) })
			}.catch { failure ->
				if (failure is CancellationException) throw failure
				emit(RecentTripsReadEvent.Failed)
			}
		}.scan(initialState()) { state, event ->
			when (event) {
				RecentTripsReadEvent.Loading -> state.copy(isLoading = true, readFailed = false)
				is RecentTripsReadEvent.Loaded -> RecentTripsUiState(event.trips, isLoading = false)
				RecentTripsReadEvent.Failed -> state.copy(isLoading = false, readFailed = true)
			}
		},
	)
}
