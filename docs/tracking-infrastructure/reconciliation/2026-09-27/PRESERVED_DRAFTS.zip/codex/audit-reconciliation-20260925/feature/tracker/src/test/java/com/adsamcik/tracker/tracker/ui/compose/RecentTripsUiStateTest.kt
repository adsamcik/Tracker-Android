package com.adsamcik.tracker.tracker.ui.compose

import com.adsamcik.tracker.shared.model.SegmentSource
import com.adsamcik.tracker.shared.model.Trip
import io.kotest.matchers.shouldBe
import java.io.IOException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class RecentTripsUiStateTest {
	@Test
	fun `failed read retains rows and retry starts a fresh observation`() = runTest {
		val reload = MutableStateFlow(0L)
		val states = mutableListOf<RecentTripsUiState>()
		var attempts = 0
		backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
			observeRecentTripsUiState(reload) {
				attempts++
				if (attempts == 1) flow {
					emit(listOf(TRIP))
					throw IOException("unavailable")
				} else flowOf(emptyList())
			}.toList(states)
		}
		runCurrent()

		states.last() shouldBe RecentTripsUiState(listOf(TRIP), false, true)
		reload.value++
		runCurrent()

		attempts shouldBe 2
		states.last() shouldBe RecentTripsUiState(emptyList(), false, false)
		states.any { it.isLoading && it.trips == listOf(TRIP) } shouldBe true
	}

	@Test
	fun `initial unavailable read is not a successful empty result`() = runTest {
		val states = mutableListOf<RecentTripsUiState>()
		backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
			observeRecentTripsUiState(flowOf(0L)) {
				flow { throw IOException("unavailable") }
			}.toList(states)
		}
		runCurrent()
		states.last() shouldBe RecentTripsUiState(emptyList(), false, true)
	}

	@Test
	fun `cancellation does not become a read failure`() = runTest {
		val states = mutableListOf<RecentTripsUiState>()
		val observation = launch(UnconfinedTestDispatcher(testScheduler)) {
			observeRecentTripsUiState(flowOf(0L)) {
				flow { awaitCancellation() }
			}.toList(states)
		}
		runCurrent()
		observation.cancelAndJoin()
		states.any { it.readFailed } shouldBe false
	}

	private companion object {
		val TRIP = Trip(1L, 1_000L, 2_000L, 100f, null, null, null, 1, SegmentSource.USER_CREATED, 1_000L)
	}
}
