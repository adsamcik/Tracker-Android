package com.adsamcik.tracker.shared.base.database.dao

import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Embedded
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.adsamcik.tracker.shared.base.database.data.LocationAcceptedProvenanceEntity

/** Canonical coordinates coupled to the accepted owner in one current, retained read. */
data class LocationAcceptedProvenanceReadRow(
	@Embedded val provenance: LocationAcceptedProvenanceEntity,
	@ColumnInfo(name = "lat_e7") val latE7: Int?,
	@ColumnInfo(name = "lon_e7") val lonE7: Int?,
	@ColumnInfo(name = "h_acc_m") val hAccM: Float?,
)

/** Exact accepted Location owner writes and bounded current-retention reads. */
@Dao
interface LocationAcceptedProvenanceDao {
	@Insert(onConflict = OnConflictStrategy.ABORT)
	suspend fun insert(row: LocationAcceptedProvenanceEntity)

	@Query("SELECT * FROM location_accepted_provenance WHERE source_event_id = :sourceEventId LIMIT 1")
	suspend fun bySourceEventId(sourceEventId: String): LocationAcceptedProvenanceEntity?

	/**
	 * Current retained accepted facts for one exact physical segment. The join prevents an orphan,
	 * rejected or substituted sample from becoming a map/history owner. A bounded caller may ask
	 * for cap plus one to report truncation instead of silently claiming complete coverage. Paging
	 * uses the stable observed-time/source-event pair; pass both cursor fields or neither.
	 */
	@Query(
		"SELECT provenance.*, sample.lat_e7 AS lat_e7, sample.lon_e7 AS lon_e7, " +
			"sample.h_acc_m AS h_acc_m FROM location_accepted_provenance AS provenance " +
			"INNER JOIN location_sample AS sample ON sample.id = provenance.sample_id " +
			"AND sample.source_event_id = provenance.source_event_id " +
			"AND sample.source_signal_id = provenance.sample_source_signal_id " +
			"AND sample.time_ms = provenance.observed_wall_time_ms " +
			"AND sample.elapsed_realtime_nanos = provenance.observed_elapsed_realtime_nanos " +
			"AND sample.clock_domain_id = provenance.clock_domain_id " +
			"AND sample.boot_clock_domain_id = provenance.boot_clock_domain_id " +
			"INNER JOIN location_observation_decision AS decision " +
			"ON decision.observation_source_event_id = provenance.source_event_id " +
			"AND decision.decision = 'ACCEPTED' " +
			"AND decision.accepted_sample_source_signal_id = provenance.sample_source_signal_id " +
			"INNER JOIN source_evidence_state AS evidence ON evidence.id = 1 " +
			"AND evidence.collected_data_epoch = provenance.captured_collected_data_epoch " +
			"AND (evidence.retained_from_ms IS NULL " +
			"OR provenance.observed_wall_time_ms >= evidence.retained_from_ms) " +
			"WHERE provenance.session_segment_id = :segmentId " +
			"AND provenance.observed_wall_time_ms >= :fromMs " +
			"AND provenance.observed_wall_time_ms < :toMs " +
			"AND ((:afterTimeMs IS NULL AND :afterSourceEventId IS NULL) " +
			"OR (:afterTimeMs IS NOT NULL AND :afterSourceEventId IS NOT NULL " +
			"AND (provenance.observed_wall_time_ms > :afterTimeMs " +
			"OR (provenance.observed_wall_time_ms = :afterTimeMs " +
			"AND provenance.source_event_id > :afterSourceEventId)))) " +
			"ORDER BY provenance.observed_wall_time_ms ASC, provenance.source_event_id ASC " +
			"LIMIT CASE WHEN :limit BETWEEN 1 AND 257 THEN :limit ELSE 0 END",
	)
	suspend fun forSegmentBetween(
		segmentId: Long,
		fromMs: Long,
		toMs: Long,
		afterTimeMs: Long?,
		afterSourceEventId: String?,
		limit: Int,
	): List<LocationAcceptedProvenanceReadRow>

	@Query("DELETE FROM location_accepted_provenance")
	fun deleteAll()
}
