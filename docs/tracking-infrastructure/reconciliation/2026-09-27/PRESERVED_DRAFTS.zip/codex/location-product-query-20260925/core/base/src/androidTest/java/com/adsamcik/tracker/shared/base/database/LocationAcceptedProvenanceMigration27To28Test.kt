package com.adsamcik.tracker.shared.base.database

import android.content.Context
import androidx.room.testing.MigrationTestHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class LocationAcceptedProvenanceMigration27To28Test {
	@get:Rule
	val helper = MigrationTestHelper(
		InstrumentationRegistry.getInstrumentation(),
		AppDatabase::class.java,
		emptyList(),
		FrameworkSQLiteOpenHelperFactory(),
	)

	private val context: Context
		get() = InstrumentationRegistry.getInstrumentation().targetContext

	@After
	fun cleanup() {
		context.deleteDatabase(DATABASE)
	}

	@Test
	fun migrationCreatesAcceptedLocationOwnerWithCascadingCanonicalSample() {
		helper.createDatabase(DATABASE, 27).close()
		helper.runMigrationsAndValidate(DATABASE, 28, true, MIGRATION_27_28).use { database ->
			val columns = buildSet {
				database.query("PRAGMA table_info('location_accepted_provenance')").use { cursor ->
					val column = cursor.getColumnIndexOrThrow("name")
					while (cursor.moveToNext()) add(cursor.getString(column))
				}
			}
			assertTrue(columns.containsAll(listOf(
				"source_event_id", "sample_id", "logical_tracking_id", "service_run_id",
				"session_segment_id", "captured_collected_data_epoch", "capture_consent_epoch",
				"boot_clock_domain_id", "clock_domain_id", "observed_wall_time_ms",
			)))
			database.query("PRAGMA foreign_key_list('location_accepted_provenance')").use { cursor ->
				assertTrue(cursor.moveToFirst())
				assertEquals("location_sample", cursor.getString(cursor.getColumnIndexOrThrow("table")))
				assertEquals("CASCADE", cursor.getString(cursor.getColumnIndexOrThrow("on_delete")))
			}
		}
	}

	private companion object {
		const val DATABASE = "migration-27-28-location-accepted-provenance"
	}
}
