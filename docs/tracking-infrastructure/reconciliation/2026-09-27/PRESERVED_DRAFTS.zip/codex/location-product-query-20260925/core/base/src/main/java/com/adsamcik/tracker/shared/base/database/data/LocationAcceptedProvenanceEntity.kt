package com.adsamcik.tracker.shared.base.database.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Exact physical owner of one accepted protected Location sample after its source WAL is pruned.
 * The protected handoff inserts this only after verifying the canonical observation, decision,
 * sample and content receipt, in the same transaction as its contiguous WAL cursor advance.
 * Deleting the canonical sample also deletes this query carrier.
 */
@Entity(
	tableName = "location_accepted_provenance",
	foreignKeys = [
		ForeignKey(
			entity = LocationSample::class,
			parentColumns = ["id"],
			childColumns = ["sample_id"],
			onDelete = ForeignKey.CASCADE,
		),
	],
	indices = [
		Index(value = ["sample_id"], unique = true, name = "idx_location_accepted_provenance_sample"),
		Index(
			value = ["session_segment_id", "observed_wall_time_ms", "source_event_id"],
			name = "idx_location_accepted_provenance_segment_time",
		),
		Index(value = ["logical_tracking_id"], name = "idx_location_accepted_provenance_tracking"),
	],
)
data class LocationAcceptedProvenanceEntity(
	@PrimaryKey
	@ColumnInfo(name = "source_event_id") val sourceEventId: String,
	@ColumnInfo(name = "sample_id") val sampleId: Long,
	@ColumnInfo(name = "sample_source_signal_id") val sampleSourceSignalId: String,
	@ColumnInfo(name = "logical_tracking_id") val logicalTrackingId: String,
	@ColumnInfo(name = "service_run_id") val serviceRunId: String,
	@ColumnInfo(name = "session_segment_id") val sessionSegmentId: Long,
	@ColumnInfo(name = "source_admission_ordinal") val sourceAdmissionOrdinal: Long,
	@ColumnInfo(name = "source_instance_id") val sourceInstanceId: String,
	@ColumnInfo(name = "registration_generation") val registrationGeneration: Long,
	@ColumnInfo(name = "source_sequence") val sourceSequence: Long,
	@ColumnInfo(name = "captured_collected_data_epoch") val capturedCollectedDataEpoch: Long,
	@ColumnInfo(name = "capture_consent_epoch") val captureConsentEpoch: Long,
	@ColumnInfo(name = "session_manifest_revision") val sessionManifestRevision: Long,
	@ColumnInfo(name = "source_policy_revision") val sourcePolicyRevision: Long,
	@ColumnInfo(name = "boot_clock_domain_id") val bootClockDomainId: String,
	@ColumnInfo(name = "clock_domain_id") val clockDomainId: String,
	@ColumnInfo(name = "observed_elapsed_realtime_nanos") val observedElapsedRealtimeNanos: Long,
	@ColumnInfo(name = "observed_wall_time_ms") val observedWallTimeMs: Long,
) {
	init {
		require(sourceEventId.isNotBlank() && sampleSourceSignalId.isNotBlank())
		require(logicalTrackingId.isNotBlank() && serviceRunId.isNotBlank())
		require(sessionSegmentId > 0L && sampleId > 0L && sourceAdmissionOrdinal > 0L)
		require(sourceInstanceId.isNotBlank() && registrationGeneration > 0L && sourceSequence >= 0L)
		require(capturedCollectedDataEpoch >= 0L && captureConsentEpoch >= 0L)
		require(sessionManifestRevision > 0L && sourcePolicyRevision > 0L)
		require(bootClockDomainId.isNotBlank() && clockDomainId.isNotBlank())
		require(observedElapsedRealtimeNanos >= 0L && observedWallTimeMs >= 0L)
	}
}
