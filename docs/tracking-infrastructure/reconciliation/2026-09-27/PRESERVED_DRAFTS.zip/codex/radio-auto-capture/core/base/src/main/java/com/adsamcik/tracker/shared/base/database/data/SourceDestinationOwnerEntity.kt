package com.adsamcik.tracker.shared.base.database.data

import androidx.room.ColumnInfo
import androidx.room.Entity

/**
 * Permanent one-writer fence for a source's logical product destination.
 *
 * Unlike product-lane/cursor state, this row survives collected-data deletion and owner rollback.
 * Every mutation command is admitted under an exact [owner] and [ownerGeneration], preventing an
 * old command from becoming valid again when ownership later returns to the same owner (ABA).
 * The row is only a fence; changing it is not sufficient to activate, cut over, or recover a writer.
 */
@Entity(
	tableName = "source_destination_owner",
	primaryKeys = ["source_kind", "destination"],
)
data class SourceDestinationOwnerEntity(
	@ColumnInfo(name = "source_kind") val sourceKind: Int,
	@ColumnInfo(name = "destination") val destination: String,
	@ColumnInfo(name = "owner") val owner: String,
	@ColumnInfo(name = "owner_generation") val ownerGeneration: Long,
	@ColumnInfo(name = "updated_at_ms") val updatedAtMs: Long,
) {
	init {
		require(sourceKind > 0)
		require(destination.isNotBlank())
		require(owner.isNotBlank())
		require(ownerGeneration > 0L)
		require(updatedAtMs >= 0L)
	}

	companion object {
		const val SOURCE_LOCATION = 1
		const val SOURCE_ACTIVITY = 2
		const val SOURCE_STEPS = 3
		const val SOURCE_PRESSURE = 4
		const val SOURCE_WIFI = 5
		const val SOURCE_CELL = 6
		const val DESTINATION_SESSION_LOCATION = "SESSION_LOCATION"
		const val DESTINATION_SESSION_ACTIVITY = "SESSION_ACTIVITY"
		const val DESTINATION_SESSION_STEPS = "SESSION_STEPS"
		const val DESTINATION_AMBIENT_STEPS = "AMBIENT_STEPS"
		const val DESTINATION_SESSION_PRESSURE = "SESSION_PRESSURE"
		const val DESTINATION_SESSION_WIFI = "SESSION_WIFI"
		const val DESTINATION_SESSION_CELL = "SESSION_CELL"
		const val OWNER_EXISTING_LOCATION_CANONICAL_PIPELINE =
			"EXISTING_LOCATION_CANONICAL_PIPELINE"
		const val OWNER_LEGACY_ACTIVITY_SNAPSHOT = "LEGACY_ACTIVITY_SNAPSHOT"
		const val OWNER_ACTIVITY_SESSION_FACTS = "ACTIVITY_SESSION_FACTS"
		const val OWNER_CONTAINED_ACTIVITY_SESSION_FACTS =
			"CONTAINED_ACTIVITY_SESSION_FACTS"
		const val OWNER_LEGACY_STEP_INTERVAL = "LEGACY_STEP_INTERVAL"
		const val OWNER_STEPS_SESSION_FACTS = "STEPS_SESSION_FACTS"
		const val OWNER_AMBIENT_STEPS_FACTS = "AMBIENT_STEPS_FACTS"
		const val OWNER_LEGACY_PRESSURE_SAMPLE = "LEGACY_PRESSURE_SAMPLE"
		const val OWNER_PRESSURE_SESSION_FACTS = "PRESSURE_SESSION_FACTS"
		const val OWNER_CONTAINED_PRESSURE_SESSION_FACTS =
			"CONTAINED_PRESSURE_SESSION_FACTS"
		const val OWNER_CELL_SESSION_FACTS = "CELL_SESSION_FACTS"
		const val OWNER_CONTAINED_CELL_SESSION_FACTS = "CONTAINED_CELL_SESSION_FACTS"
		const val OWNER_WIFI_SESSION_FACTS = "WIFI_SESSION_FACTS"
		const val OWNER_CONTAINED_WIFI_SESSION_FACTS = "CONTAINED_WIFI_SESSION_FACTS"
		const val INITIAL_EXISTING_LOCATION_GENERATION = 1L
		const val INITIAL_LEGACY_GENERATION = 1L
		/** First durable generation that permanently fences the legacy Pressure sample writer. */
		const val FIRST_LEGACY_PRESSURE_FENCE_GENERATION = 2L
		/** First owner fence for a new destination; presence alone grants no provider or rollout. */
		const val INITIAL_AMBIENT_STEPS_GENERATION = 1L
		const val FIRST_CANDIDATE_GENERATION = 2L
		const val LOCATION_CANONICAL_HANDOFF_PROJECTION_ID =
			"protected-location-canonical-handoff"
		const val LOCATION_CANONICAL_HANDOFF_PROJECTION_VERSION = 1
		const val LOCATION_CANONICAL_HANDOFF_BINDING_GENERATION = 1L
		const val STEPS_FACT_PROJECTION_ID = "steps-session-facts"
		const val STEPS_FACT_PROJECTION_VERSION = 1
		/** Immutable manual-session binding retained for already attributed v28 facts. */
		const val STEPS_FACT_BINDING_GENERATION = 1L
		/** Adds automatic-session capture without changing generation 1 semantics. */
		const val STEPS_FACT_AUTOMATIC_BINDING_GENERATION = 2L
		const val PRESSURE_FACT_PROJECTION_ID = "pressure-session-facts"
		const val PRESSURE_FACT_PROJECTION_VERSION = 1
		const val PRESSURE_FACT_BINDING_GENERATION = 1L
		const val ACTIVITY_FACT_PROJECTION_ID = "activity-session-facts"
		const val ACTIVITY_FACT_PROJECTION_VERSION = 1
		const val ACTIVITY_FACT_BINDING_GENERATION = 1L
		const val CELL_FACT_PROJECTION_ID = "cell-session-facts"
		const val CELL_FACT_PROJECTION_VERSION = 1
		const val CELL_FACT_BINDING_GENERATION = 1L
		/** Adds automatic-session capture without changing generation 1 semantics. */
		const val CELL_FACT_AUTOMATIC_BINDING_GENERATION = 2L
		const val WIFI_FACT_PROJECTION_ID = "wifi-session-facts"
		const val WIFI_FACT_PROJECTION_VERSION = 1
		const val WIFI_FACT_BINDING_GENERATION = 1L
		/** Adds automatic-session capture without changing generation 1 semantics. */
		const val WIFI_FACT_AUTOMATIC_BINDING_GENERATION = 2L

		/** Radio writer generations are exact contracts, including their immutable owner fences. */
		fun isSupportedWifiFactBinding(bindingGeneration: Long?, ownerGeneration: Long?): Boolean {
			val generation = bindingGeneration ?: return false
			if (generation != WIFI_FACT_BINDING_GENERATION &&
				generation != WIFI_FACT_AUTOMATIC_BINDING_GENERATION
			) return false
			return ownerGeneration == SourceWriterGenerationContract.canonicalOwnerGeneration(generation)
		}

		fun isSupportedCellFactBinding(bindingGeneration: Long?, ownerGeneration: Long?): Boolean {
			val generation = bindingGeneration ?: return false
			if (generation != CELL_FACT_BINDING_GENERATION &&
				generation != CELL_FACT_AUTOMATIC_BINDING_GENERATION
			) return false
			return ownerGeneration == SourceWriterGenerationContract.canonicalOwnerGeneration(generation)
		}

		fun isSupportedWifiFactOwner(ownerGeneration: Long?): Boolean =
			isSupportedWifiFactBinding(WIFI_FACT_BINDING_GENERATION, ownerGeneration) ||
				isSupportedWifiFactBinding(WIFI_FACT_AUTOMATIC_BINDING_GENERATION, ownerGeneration)

		fun isSupportedCellFactOwner(ownerGeneration: Long?): Boolean =
			isSupportedCellFactBinding(CELL_FACT_BINDING_GENERATION, ownerGeneration) ||
				isSupportedCellFactBinding(CELL_FACT_AUTOMATIC_BINDING_GENERATION, ownerGeneration)
	}
}
